﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionTriaje
{
    public partial class frmTriajeHospitalario : Form
    {
        private List<Paciente> listaPaciente = new List<Paciente>();
        public frmTriajeHospitalario()
        {
            InitializeComponent();
        }

        

        private void frmTriajeHospitalario_Load(object sender, EventArgs e)
        {

        }
        private void btnRojo_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text == "" || txtEdad.Text == "" || cmbMotivoConsuta.SelectedItem == null)
            {
                MessageBox.Show("Por favor complete todos los campos antes de registrar.");
                return;
            }

            int edad;
            if (!int.TryParse(txtEdad.Text, out edad))
            {
                MessageBox.Show("La edad debe ser un número válido.");
                return;
            }

            Paciente nuevoPaciente = new Paciente(txtNombre.Text, edad, cmbMotivoConsuta.SelectedItem.ToString(), "Rojo");
            listaPaciente.Add(nuevoPaciente);

            int fila = dgvColaEspera.Rows.Add();
            dgvColaEspera.Rows[fila].Cells["colNombre"].Value = nuevoPaciente.Nombre;
            dgvColaEspera.Rows[fila].Cells["colEdad"].Value = nuevoPaciente.Edad;
            dgvColaEspera.Rows[fila].Cells["colMotivo"].Value = nuevoPaciente.Motivo;
            dgvColaEspera.Rows[fila].Cells["colHoraIngreso"].Value = nuevoPaciente.HoraIngreso.ToString("HH:mm:ss");
            dgvColaEspera.Rows[fila].Cells["colPrioridad"].Value = nuevoPaciente.Prioridad;
            dgvColaEspera.Rows[fila].DefaultCellStyle.BackColor = Color.LightCoral;

            txtNombre.Clear();
            txtEdad.Clear();
            cmbMotivoConsuta.SelectedIndex = -1;
        }
    }
}
