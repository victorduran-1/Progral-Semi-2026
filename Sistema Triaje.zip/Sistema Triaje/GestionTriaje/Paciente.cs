﻿using System;

namespace GestionTriaje
{
    public class Paciente
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
        public string Motivo { get; set; }
        public string Prioridad { get; set; }
        public DateTime HoraIngreso { get; set; }

        public Paciente(string nombre, int edad, string motivo, string prioridad)
        {
            Nombre = nombre;
            Edad = edad;
            Motivo = motivo;
            Prioridad = prioridad;
            HoraIngreso = DateTime.Now;
        }
    }
}